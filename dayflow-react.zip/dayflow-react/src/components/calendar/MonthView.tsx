import React from 'react';
import { useApp } from '../../context/AppContext';
import { parseDate, getMonthCells, generateRecurringInstances, DAY_SHORT } from '../../utils/dateUtils';
import { useDragEvent } from '../../hooks/useDragEvent';
import EventChip from './EventChip';
import styles from './MonthView.module.css';

export default function MonthView() {
  const { state, dispatch, openNewEvent, openDailyNote } = useApp();
  const anchor = parseDate(state.currentDate);
  const cells = getMonthCells(anchor.getFullYear(), anchor.getMonth());

  const { getChipDragProps, getMonthCellDropProps } = useDragEvent();

  // for recurrance range (whats being viewed)
  const rangeStart = cells[0].dateStr;
  const rangeEnd = cells[cells.length - 1].dateStr;

  const expanded = state.events.flatMap(e =>
    generateRecurringInstances(e, rangeStart, rangeEnd)
  );
  const filtered = state.activeFilter
    ? expanded.filter(e => e.category === state.activeFilter)
    : expanded;

  const handleChipClick = (e: React.MouseEvent, eventId: string) => {
    e.stopPropagation();
    // Instance ids look like "ev_abc123_2026-01-13"
    // Strip the trailing "_YYYY-MM-DD" to get the base id
    const baseId = eventId.replace(/_\d{4}-\d{2}-\d{2}$/, '');
    const ev = state.events.find(ev => ev.id === baseId);
    if (!ev) return;
    dispatch({ type: 'SELECT_DAILY_NOTE', payload: null });
    dispatch({ type: 'SELECT_EVENT', payload: ev.id });
};

const handleDayNumClick = (e: React.MouseEvent, dateStr: string, isToday: boolean) => {
  e.stopPropagation();
  dispatch({ type: 'SET_DATE', payload: dateStr });
  dispatch({ type: 'SET_VIEW', payload: 'week' });

  // also open the daily note for that date
  openDailyNote(dateStr, isToday);
};

return (
  <div className={styles.container}>
    <div className={styles.headerRow}>
      {DAY_SHORT.map(d => (
        <div key={d} className={styles.headerCell}>{d}</div>
      ))}
    </div>

    <div className={styles.grid}>
      {cells.map(({ date, dateStr, isCurrentMonth, isToday }) => {
        const dayEvents = filtered.filter(e => e.date === dateStr);
        const dropProps = getMonthCellDropProps(dateStr);

        return (
          <div
            key={dateStr}
            className={[
              styles.cell,
              !isCurrentMonth ? styles.cellOther : '',
              isToday ? styles.cellToday : '',
            ].filter(Boolean).join(' ')}
            onClick={() => {
              dispatch({ type: 'SELECT_EVENT', payload: null });
              openNewEvent(dateStr, '09:00');
            }}
            {...dropProps}
          >
            <span
              className={`${styles.dateNum} ${isToday ? styles.dateNumToday : ''}`}
              onClick={e => handleDayNumClick(e, dateStr, isToday)}
            >
              {date.getDate()}
            </span>

            <div className={styles.events}>
              {dayEvents.slice(0, 3).map(ev => (
                <EventChip
                  key={ev.id}
                  event={ev}
                  variant="month"
                  isDragging={state.draggingEventId === ev.id}
                  dragProps={getChipDragProps(ev)}
                  onClick={e => handleChipClick(e, ev.id)}
                />
              ))}
              {dayEvents.length > 3 && (
                <div
                  className={styles.overflow}
                  onClick={e => {
                    e.stopPropagation();
                    dispatch({ type: 'SET_DATE', payload: dateStr });
                    dispatch({ type: 'SET_VIEW', payload: 'week' });
                  }}
                >
                  +{dayEvents.length - 3} more
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  </div>
);
}
